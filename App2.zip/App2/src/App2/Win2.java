package App2;
 import java.awt.event.ActionEvent; 
import java.awt.event.ActionListener; 
import java.io.*; 
 
import javax.swing.*; 
 
class ClassApp2 implements ActionListener { 
FileReaderClass File = new FileReaderClass(); 
JTextArea textArea; 
public ClassApp2(String text, int x, int y) { 
JFrame rop = new JFrame("Справка"); 
rop.setBounds(x, y, 450, 700); 
rop.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); 
rop.setLayout(null); 
textArea = new JTextArea(); 
textArea.setBounds(50,50, 330, 250); 
textArea.setEditable(false); 
textArea.append(File.read()); 
rop.add(textArea); 
rop.setVisible(true); 
} 
public void actionPerformed(ActionEvent ae) { 

} 
} 
class FileReaderClass { 
public String read() { 
StringBuilder bin = new StringBuilder(); 
try { 
String s; 
FileReader fr = new FileReader("C:/bublik/xanadu.txt"); 
BufferedReader br = new BufferedReader(fr); 
LineNumberReader lr = new LineNumberReader(br); 
while ((s = lr.readLine()) != null) { 
bin.append(s); 
bin.append("\n"); 
} 
} catch (IOException e) { 
System.out.println(e.getMessage()); 
} 
return bin.toString(); 
} 

}  