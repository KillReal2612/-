package App2;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.*; 
import javax.swing.*; 
public class App2 {
    public static void main(String[] args) {
      JFrame frame = new JFrame("Мое приложение");
frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); 
frame.setSize(800,600);
frame.setVisible(true);
JPanel p1 = new JPanel(new BorderLayout()); 
JButton butt = new JButton("Начать работу"); 
butt.setVisible(true); 
butt.setLocation(300, 330); 
butt.setSize(200, 100); 
JButton butt2 = new JButton("Подробнее о программе");
butt2.setLocation(500,500);
butt2.addActionListener(new ActionListener() { 
    
public void actionPerformed(ActionEvent e) { 
new ClassApp2("Справка", 450, 10); 
} 
});
butt2.setVisible(true); 
butt2.setLocation(600, 500); 
butt2.setSize(200, 70); 
frame.getContentPane().add(butt); 
frame.getContentPane().add(new JLabel()); 
frame.getContentPane().add(butt2); 
frame.getContentPane().add(new JLabel()); 
class Canvas extends JComponent{
  @Override
  public void paintComponent(Graphics g){

      g.setColor (Color.orange);
g.fillArc (100,20,80,80,0,360);
g.drawLine (95,55,75,55);
g.drawLine (140,105,140,125);
g.drawLine (140,15,140,0);
g.drawLine (185,60,205,60);
g.drawLine (105,35,85,25);
g.drawLine (120,20,105,5);
g.drawLine (100,80,80,90);
g.drawLine (115,100,100,120);
g.drawLine (175,5,160,20);
g.drawLine (205,25,175,35);
g.drawLine (205,90,175,80);
g.drawLine (175,120,160,100);  
      g.setColor (Color.BLACK);
      Font font = new Font("f" ,Font.ROMAN_BASELINE|Font.PLAIN, 40);
         g.setFont(font); 
          g.drawString("Приятного пользования! ", 150, 200);


  }
}
Canvas canv=new Canvas();
        frame.add(canv);		
        frame.setVisible(true);	
    }
    
}
